#include <iostream>
#include "Vehicle.h"
#include <stack>

using namespace std;
void runner_main()
{
	stack<Vehicle> vehicleList;
	Vehicle vehicle1("Black", 123451), vehicle2("Blue", 123452), vehicle3("Red", 123453), vehicle4("Yellow", 123454), vehicle5("White", 123455);
	vehicleList.push(vehicle1);
	vehicleList.push(vehicle2);
	vehicleList.push(vehicle3);
	vehicleList.push(vehicle4);
	vehicleList.push(vehicle5);
	for (int index = 1;index <= 5;index++)
	{
		cout << "Vehicle No." << index << " : ";
		vehicleList.top().print();
		vehicleList.pop();
	}

}
int main()
{
	runner_main();

	return 0;
}
